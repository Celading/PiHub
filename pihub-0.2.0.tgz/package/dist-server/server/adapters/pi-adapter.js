import { EventEmitter } from 'node:events';
import { normalizePiEvent, } from './types.js';
/**
 * P2-01a: pi as the first AgentAdapter. Wraps the existing RpcBridge so the
 * current protocol surface (JSONL over stdio, LF framing, id-correlated
 * responses) is untouched — every raw RpcStreamEvent is ALSO emitted as a
 * normalized AgentEvent on this adapter's OWN emitter (raw payload preserved
 * via adapter_extension), so consumers never read raw frames directly.
 */
export class PiAdapter extends EventEmitter {
    bridge;
    meta = {
        kind: 'pi',
        label: 'pi',
        version: null,
        defaultColor: '#005fb8',
    };
    constructor(bridge) {
        super();
        this.bridge = bridge;
        bridge.on('event', (raw) => {
            for (const event of normalizePiEvent(raw)) {
                this.emit('event', event);
            }
        });
        // Re-broadcast lifecycle so adapter consumers stay protocol-neutral.
        bridge.on('exit', (code) => this.emit('exit', code));
        bridge.on('error', (error) => this.emit('error', error));
        bridge.on('ui-request', (request) => this.emit('ui-request', request));
        bridge.on('response', (response) => this.emit('response', response));
    }
    on(event, listener) {
        return super.on(event, listener);
    }
    off(event, listener) {
        return super.off(event, listener);
    }
    isRunning() {
        return this.bridge.isRunning();
    }
    start() {
        this.bridge.start();
    }
    stop() {
        this.bridge.stop();
    }
    restart() {
        this.bridge.restart();
    }
    async send(command) {
        switch (command.type) {
            case 'prompt':
                return this.bridge.send({
                    type: 'prompt',
                    message: command.message,
                    ...(command.streamingBehavior !== undefined
                        ? { streamingBehavior: command.streamingBehavior }
                        : {}),
                });
            case 'steer':
                return this.bridge.send({ type: 'steer', message: command.message });
            case 'abort':
                return this.bridge.send({ type: 'abort' });
            case 'switch_session':
                return this.bridge.send({ type: 'switch_session', sessionPath: command.sessionId });
            case 'set_model':
                return this.bridge.send({
                    type: 'set_model',
                    provider: command.provider,
                    modelId: command.modelId,
                });
            case 'set_thinking_level':
                return this.bridge.send({ type: 'set_thinking_level', level: command.level });
            case 'get_state':
                return this.bridge.send({ type: 'get_state' });
            case 'get_messages':
                return this.bridge.send({ type: 'get_messages' });
            case 'get_tree':
                return this.bridge.send({ type: 'get_tree' });
            default:
                // Exhaustive switch: unreachable with the current union, kept for
                // future command additions.
                return {
                    type: 'response',
                    command: command.type,
                    success: false,
                    error: 'pi adapter: unsupported command',
                };
        }
    }
}
