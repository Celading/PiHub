import { spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { extensionUiRequestSchema, rpcResponseSchema, rpcStreamEventSchema } from '../shared/schemas.js';
const MAX_RESTARTS = 3;
const RESTART_BACKOFF_MS = 1000;
const RESPONSE_TIMEOUT_MS = 30_000;
/**
 * Manages a `pi --mode rpc` subprocess: JSONL over stdio.
 * - stdout is split strictly on `\n` (trailing `\r` stripped), per the
 *   documented framing (never use readline: U+2028/2029 are valid in JSON).
 * - requests are correlated by id; the response for prompt/steer/etc. arrives
 *   immediately after acceptance while events keep streaming afterwards.
 */
export class RpcBridge extends EventEmitter {
    piBinary;
    cwd;
    child = null;
    pending = new Map();
    pendingUi = new Map();
    nextId = 1;
    buffer = '';
    restartCount = 0;
    stopped = false;
    /** SPRINT-2 B4: per-process monotonic event sequence (event envelope). */
    sequence = 0;
    /** Current pi session id (from session header events), for the envelope. */
    sessionId = null;
    /** Current pipeline run id, when a pipeline step is driving pi. */
    runId = null;
    constructor(piBinary, cwd) {
        super();
        this.piBinary = piBinary;
        this.cwd = cwd;
    }
    on(event, listener) {
        return super.on(event, listener);
    }
    emit(event, ...args) {
        return super.emit(event, ...args);
    }
    start() {
        if (this.stopped || this.child !== null) {
            return;
        }
        this.child = spawn(this.piBinary, ['--mode', 'rpc'], {
            cwd: this.cwd,
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        this.child.stdout.setEncoding('utf8');
        this.child.stdout.on('data', (chunk) => {
            this.buffer += chunk;
            let newlineIndex = this.buffer.indexOf('\n');
            while (newlineIndex !== -1) {
                const line = this.buffer.slice(0, newlineIndex);
                this.buffer = this.buffer.slice(newlineIndex + 1);
                this.handleLine(line);
                newlineIndex = this.buffer.indexOf('\n');
            }
        });
        this.child.stderr.setEncoding('utf8');
        this.child.stderr.on('data', (chunk) => {
            this.emit('error', new Error(`pi stderr: ${chunk.trimEnd()}`));
        });
        const exitedChild = this.child;
        this.child.on('exit', (code) => {
            // SPRINT-2 A2: only clear the reference if this is still the current
            // child. A deliberate restart() kills the old process and spawns a new
            // one; if the old process's exit event fires AFTER the new child was
            // assigned, unconditionally nulling this.child would drop the new
            // process (orphan + duplicate pi).
            if (this.child === exitedChild) {
                this.child = null;
            }
            this.emit('exit', code);
            for (const pending of this.pending.values()) {
                clearTimeout(pending.timer);
                pending.reject(new Error(`pi process exited with code ${String(code)}`));
            }
            this.pending.clear();
            if (!this.stopped && this.restartCount < MAX_RESTARTS) {
                this.restartCount += 1;
                setTimeout(() => {
                    if (!this.stopped) {
                        this.start();
                    }
                }, RESTART_BACKOFF_MS * this.restartCount);
            }
        });
        this.child.on('error', (error) => {
            this.emit('error', error);
        });
    }
    stop() {
        this.stopped = true;
        if (this.child !== null) {
            this.child.kill('SIGTERM');
        }
    }
    /**
     * Deliberate restart of the pi child (P1-15): pi loads models.json once at
     * process start, so a channel-config save must respawn the runtime to
     * compose updated providers. The panel is session-path-driven — every
     * prompt/steer re-switches to the current session file — so a restart does
     * not detach the active session.
     */
    restart() {
        if (this.stopped || this.child === null) {
            return;
        }
        const child = this.child;
        this.child = null;
        for (const pending of this.pending.values()) {
            clearTimeout(pending.timer);
            pending.reject(new Error('pi process restarted for model config reload'));
        }
        this.pending.clear();
        child.kill('SIGTERM');
        this.start();
    }
    isRunning() {
        return this.child !== null;
    }
    /** Number of in-flight RPC requests awaiting a response (debug channel). */
    pendingRequestCount() {
        return this.pending.size;
    }
    /** Fire-and-forget command with response correlation. */
    send(command) {
        const id = `pi-panel-${String(this.nextId)}`;
        this.nextId += 1;
        return this.sendRaw({ id, ...command });
    }
    sendRaw(payload) {
        if (this.child === null) {
            return Promise.reject(new Error('pi process is not running'));
        }
        const id = payload['id'];
        const hasId = typeof id === 'string';
        const promise = new Promise((resolve, reject) => {
            if (!hasId) {
                // No correlation possible; resolve once the next response arrives.
                const timer = setTimeout(() => {
                    reject(new Error('RPC response timeout'));
                }, RESPONSE_TIMEOUT_MS);
                this.once('response', (response) => {
                    clearTimeout(timer);
                    resolve(response);
                });
                return;
            }
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error(`RPC response timeout for ${id}`));
            }, RESPONSE_TIMEOUT_MS);
            this.pending.set(id, { resolve, reject, timer });
        });
        this.child.stdin.write(`${JSON.stringify(payload)}\n`);
        return promise;
    }
    /** Pending dialog requests the frontend still owes an answer for. */
    getPendingUiRequests() {
        return [...this.pendingUi.values()].map((entry) => entry.request);
    }
    /** Answer an extension UI dialog request back on stdin. */
    sendUiResponse(response) {
        if (this.child === null) {
            return false;
        }
        const pending = this.pendingUi.get(response.id);
        if (pending === undefined) {
            return false;
        }
        if (pending.timer !== null) {
            clearTimeout(pending.timer);
        }
        this.pendingUi.delete(response.id);
        const payload = {
            type: 'extension_ui_response',
            id: response.id,
        };
        if (response.cancelled === true) {
            payload['cancelled'] = true;
        }
        else if (response.confirmed !== undefined) {
            payload['confirmed'] = response.confirmed;
        }
        else {
            payload['value'] = response.value ?? '';
        }
        this.child.stdin.write(`${JSON.stringify(payload)}\n`);
        return true;
    }
    handleLine(line) {
        const trimmed = line.endsWith('\r') ? line.slice(0, -1) : line;
        if (trimmed.length === 0) {
            return;
        }
        let parsed;
        try {
            parsed = JSON.parse(trimmed);
        }
        catch {
            this.emit('error', new Error('invalid JSON line from pi stdout'));
            return;
        }
        if (typeof parsed !== 'object' || parsed === null) {
            return;
        }
        const record = parsed;
        if (record['type'] === 'extension_ui_request') {
            const request = extensionUiRequestSchema.safeParse(record);
            if (!request.success) {
                this.emit('error', new Error('invalid extension_ui_request shape from pi'));
                return;
            }
            const data = request.data;
            const dialogMethods = ['select', 'confirm', 'input', 'editor'];
            if (dialogMethods.includes(data.method)) {
                // Dialog: hold until the frontend answers (agent auto-resolves on
                // timeout — we only relay the timeout hint to the UI).
                const timeout = 'timeout' in data ? data.timeout : undefined;
                const timer = typeof timeout === 'number'
                    ? setTimeout(() => {
                        this.pendingUi.delete(data.id);
                    }, timeout)
                    : null;
                this.pendingUi.set(data.id, { request: data, timer });
            }
            this.emit('ui-request', data);
            return;
        }
        if (record['type'] === 'response') {
            const response = rpcResponseSchema.safeParse(record);
            if (!response.success) {
                this.emit('error', new Error('invalid response shape from pi'));
                return;
            }
            const id = response.data.id;
            if (typeof id === 'string') {
                const pending = this.pending.get(id);
                if (pending !== undefined) {
                    clearTimeout(pending.timer);
                    this.pending.delete(id);
                    pending.resolve(response.data);
                }
            }
            this.emit('response', response.data);
            return;
        }
        const event = rpcStreamEventSchema.safeParse(record);
        if (!event.success) {
            return;
        }
        // SPRINT-2 B4: stable event envelope — a per-process monotonic sequence
        // plus optional session/run ids, so parallel runs and replay tooling can
        // order and correlate frames without guessing from `type` alone. Original
        // protocol payload is preserved untouched (loose schema).
        const data = event.data;
        this.sequence += 1;
        data.sequence = this.sequence;
        if (data.sessionId === undefined && this.sessionId !== null) {
            data.sessionId = this.sessionId;
        }
        if (data.runId === undefined && this.runId !== null) {
            data.runId = this.runId;
        }
        this.emit('event', data);
    }
}
