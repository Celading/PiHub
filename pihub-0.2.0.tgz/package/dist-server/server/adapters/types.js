/** Bridges one raw RpcStreamEvent frame into semantic AgentEvent(s). */
export function normalizePiEvent(raw) {
    const envelope = {
        ...(typeof raw.sessionId === 'string' ? { sessionId: raw.sessionId } : {}),
        ...(typeof raw.runId === 'string' ? { runId: raw.runId } : {}),
    };
    switch (raw.type) {
        case 'agent_start':
            return [{ type: 'agent_start', ...envelope }];
        case 'agent_end':
            return [{ type: 'agent_end', ...envelope }];
        case 'agent_settled':
            return [{ type: 'agent_settled', ...envelope }];
        case 'message_update':
            return [{ type: 'message_update', ...envelope, message: raw.message }];
        case 'model_change':
            return [
                {
                    type: 'model_change',
                    ...envelope,
                    provider: typeof raw.provider === 'string' ? raw.provider : '',
                    modelId: typeof raw.modelId === 'string' ? raw.modelId : '',
                },
            ];
        case 'thinking_level_change':
            return [
                {
                    type: 'thinking_level_change',
                    ...envelope,
                    level: typeof raw.thinkingLevel === 'string' ? raw.thinkingLevel : '',
                },
            ];
        case 'compaction_start':
            return [{ type: 'compaction_start' }];
        case 'compaction_end':
            return [{ type: 'compaction_end' }];
        case 'pipeline_step':
            return [{ type: 'pipeline_step', run: raw.run }];
        default:
            // Unknown extension frames are relayed untouched so nothing is lost.
            return [{ type: 'adapter_extension', kind: 'pi', payload: raw }];
    }
}
