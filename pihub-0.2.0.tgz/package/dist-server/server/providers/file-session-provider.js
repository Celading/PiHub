import { createSessionStore } from '../sessions.js';
export function createFileSessionProvider(dir) {
    return createSessionStore(dir);
}
