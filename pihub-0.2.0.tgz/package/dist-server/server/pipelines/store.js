/**
 * Pipeline definitions and run history persistence (P1-02-C).
 *
 * PiHub-owned data lives under `~/.pihub` — never inside `~/.pi`. The store
 * is injectable with a base directory so tests run against temp dirs.
 * Definitions are validated with the zod pipeline schema on every read and
 * write; a corrupted file is backed up (not silently dropped) and re-read as
 * empty.
 */
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, } from 'node:fs';
import { homedir } from 'node:os';
import path from 'node:path';
import { pipelineSchema } from '../../shared/schemas.js';
const PIPELINES_FILE = 'pipelines.json';
const RUNS_DIR = 'pipeline-runs';
const MAX_RUN_LINES = 500;
export function createPipelineStore(baseDir = path.join(homedir(), '.pihub')) {
    const defsPath = path.join(baseDir, PIPELINES_FILE);
    const runsDir = path.join(baseDir, RUNS_DIR);
    const ensureDirs = () => {
        mkdirSync(baseDir, { recursive: true });
        mkdirSync(runsDir, { recursive: true });
    };
    const readDefs = () => {
        if (!existsSync(defsPath)) {
            return [];
        }
        let raw;
        try {
            raw = readFileSync(defsPath, 'utf8');
        }
        catch {
            return [];
        }
        try {
            const parsed = JSON.parse(raw);
            const file = parsed;
            const list = Array.isArray(file.pipelines) ? file.pipelines : [];
            return list.filter((p) => pipelineSchema.safeParse(p).success);
        }
        catch {
            // Corrupted definitions file: preserve the original bytes for recovery,
            // then start fresh instead of overwriting silently.
            try {
                renameSync(defsPath, `${defsPath}.corrupt-${String(Date.now())}`);
            }
            catch {
                // backup failed; still proceed with an empty store
            }
            return [];
        }
    };
    const writeDefs = (pipelines) => {
        ensureDirs();
        const payload = { pipelines };
        const tmpPath = `${defsPath}.tmp`;
        writeFileSync(tmpPath, JSON.stringify(payload, null, 2), 'utf8');
        renameSync(tmpPath, defsPath);
    };
    const runLogPath = (pipelineId) => path.join(runsDir, `${pipelineId}.jsonl`);
    return {
        list() {
            return readDefs();
        },
        get(id) {
            return readDefs().find((p) => p.id === id);
        },
        save(pipeline) {
            const validated = pipelineSchema.parse(pipeline); // throws on invalid
            const rest = readDefs().filter((p) => p.id !== validated.id);
            const all = [...rest, validated].sort((a, b) => a.name.localeCompare(b.name));
            writeDefs(all);
            return validated;
        },
        remove(id) {
            const rest = readDefs().filter((p) => p.id !== id);
            if (rest.length === readDefs().length) {
                return false;
            }
            writeDefs(rest);
            return true;
        },
        appendRunLine(pipelineId, line) {
            ensureDirs();
            const logPath = runLogPath(pipelineId);
            appendFileSync(logPath, `${JSON.stringify(line)}\n`, 'utf8');
            // Keep the log bounded: rewrite with the last MAX_RUN_LINES lines.
            if (existsSync(logPath)) {
                const lines = readFileSync(logPath, 'utf8').split('\n');
                if (lines.length > MAX_RUN_LINES + 1) {
                    writeFileSync(logPath, lines.slice(-MAX_RUN_LINES).join('\n'), 'utf8');
                }
            }
        },
        readRunLog(pipelineId) {
            const logPath = runLogPath(pipelineId);
            if (!existsSync(logPath)) {
                return [];
            }
            try {
                const lines = readFileSync(logPath, 'utf8').split('\n').filter((l) => l.length > 0);
                const records = [];
                for (const line of lines.slice(-MAX_RUN_LINES)) {
                    try {
                        records.push(JSON.parse(line));
                    }
                    catch {
                        // malformed historical line; skip
                    }
                }
                return records;
            }
            catch {
                return [];
            }
        },
    };
}
